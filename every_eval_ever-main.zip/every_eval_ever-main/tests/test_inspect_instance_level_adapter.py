import pytest

pytest.importorskip(
    'inspect_ai',
    reason='inspect-ai not installed; install with: uv sync --extra inspect',
)

import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from inspect_ai.model import ChatMessageAssistant, ChatMessageUser, ContentText

from every_eval_ever.converters.inspect.adapter import InspectAIAdapter
from every_eval_ever.converters.inspect.instance_level_adapter import (
    InspectInstanceLevelDataAdapter,
)
from every_eval_ever.eval_types import EvaluatorRelationship
from every_eval_ever.instance_level_types import (
    InstanceLevelEvaluationLog,
    InteractionType,
)


def _load_instance_level_data(adapter, filepath, metadata_args):
    eval_filepath = Path(filepath)

    with tempfile.TemporaryDirectory() as tmpdir:
        metadata_args['parent_eval_output_dir'] = tmpdir
        converted_eval = adapter.transform_from_file(
            eval_filepath, metadata_args=metadata_args
        )

        instance_level_path = Path(
            converted_eval.detailed_evaluation_results.file_path
        )
        instance_logs = []
        with instance_level_path.open('r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    instance_logs.append(
                        InstanceLevelEvaluationLog.model_validate(data)
                    )

    return converted_eval, instance_logs


def test_pubmedqa_instance_level():
    adapter = InspectAIAdapter()

    with tempfile.TemporaryDirectory() as tmpdir:
        metadata_args = {
            'source_organization_name': 'TestOrg',
            'evaluator_relationship': EvaluatorRelationship.first_party,
            'parent_eval_output_dir': tmpdir,
            'file_uuid': 'test_pubmedqa',
        }

        converted_eval, instance_logs = _load_instance_level_data(
            adapter,
            'tests/data/inspect/data_pubmedqa_gpt4o_mini.json',
            metadata_args,
        )

        assert len(instance_logs) == 2
        log = instance_logs[0]

        assert log.schema_version == '0.2.2'
        assert log.model_id == 'openai/gpt-4o-mini-2024-07-18'
        assert log.interaction_type == InteractionType.single_turn

        assert log.input.raw.startswith('Context')

        assert log.output.raw == ['A']
        assert log.messages is None

        assert log.evaluation.score == 1.0
        assert log.evaluation.is_correct is True


def test_arc_sonnet_instance_level():
    adapter = InspectAIAdapter()

    with tempfile.TemporaryDirectory() as tmpdir:
        metadata_args = {
            'source_organization_name': 'TestOrg',
            'evaluator_relationship': EvaluatorRelationship.first_party,
            'parent_eval_output_dir': tmpdir,
            'file_uuid': 'test_arc_sonnet',
        }

        converted_eval, instance_logs = _load_instance_level_data(
            adapter, 'tests/data/inspect/data_arc_sonnet.json', metadata_args
        )

        assert len(instance_logs) == 5
        log = instance_logs[0]

        assert log.schema_version == '0.2.2'
        assert log.model_id == 'anthropic/claude-sonnet-4-20250514'
        assert log.interaction_type == InteractionType.single_turn

        assert len(log.input.choices) == 4
        assert 'Sunlight is the source of energy' in log.input.choices[0]

        assert log.output.raw == ['A']
        assert log.messages is None

        assert log.evaluation.score == 1.0
        assert log.evaluation.is_correct is True

        assert log.token_usage.input_tokens > 0
        assert log.token_usage.output_tokens > 0
        assert log.token_usage.total_tokens > 0


def test_arc_qwen_instance_level():
    adapter = InspectAIAdapter()

    with tempfile.TemporaryDirectory() as tmpdir:
        metadata_args = {
            'source_organization_name': 'TestOrg',
            'evaluator_relationship': EvaluatorRelationship.first_party,
            'parent_eval_output_dir': tmpdir,
            'file_uuid': 'test_arc_qwen',
        }

        converted_eval, instance_logs = _load_instance_level_data(
            adapter, 'tests/data/inspect/data_arc_qwen.json', metadata_args
        )

        assert len(instance_logs) == 3
        log = instance_logs[0]

        assert log.schema_version == '0.2.2'
        assert log.model_id == 'ollama/qwen2.5-0.5b'
        assert log.interaction_type == InteractionType.single_turn

        assert log.input.choices == [
            'Sunlight is the source of energy for nearly all ecosystems.',
            'Most ecosystems are found on land instead of in water.',
            'Carbon dioxide is more available than other gases.',
            'The producers in all ecosystems are plants.',
        ]

        assert log.evaluation.score == 1.0

        assert log.performance.latency_ms > 0


def test_gaia_instance_level():
    adapter = InspectAIAdapter()

    with tempfile.TemporaryDirectory() as tmpdir:
        metadata_args = {
            'source_organization_name': 'TestOrg',
            'evaluator_relationship': EvaluatorRelationship.first_party,
            'parent_eval_output_dir': tmpdir,
            'file_uuid': 'test_gaia',
        }

        converted_eval, instance_logs = _load_instance_level_data(
            adapter,
            'tests/data/inspect/2026-02-07T11-26-57+00-00_gaia_4V8zHbbRKpU5Yv2BMoBcjE.json',
            metadata_args,
        )

        assert len(instance_logs) > 0
        log = instance_logs[0]

        assert log.schema_version == '0.2.2'
        assert log.model_id == 'openai/gpt-4.1-mini-2025-04-14'

        assert log.interaction_type == InteractionType.agentic

        assert log.input.raw is not None or log.input.choices is not None

        assert log.output is None
        assert log.messages is not None
        assert any([i.role for i in log.messages if i.role == 'tool'])

        assert len(log.messages) > 2
        assert log.messages[0].turn_idx == 0
        assert log.messages[0].role == 'system'
        assert log.messages[1].role == 'user'

        assert log.evaluation.score >= 0.0

        assert log.token_usage is not None
        assert log.token_usage.input_tokens >= 0
        assert log.token_usage.output_tokens >= 0


def test_serialize_input_skips_non_user_messages():
    adapter = InspectInstanceLevelDataAdapter(
        'test_id', 'test_id', 'jsonl', 'sha256', '/tmp'
    )

    user_msg = ChatMessageUser(content='user question')
    assistant_msg = ChatMessageAssistant(content='assistant answer')

    result = adapter._serialize_input([assistant_msg, user_msg])
    assert result == 'user question'
    assert 'assistant answer' not in result


def test_serialize_input_concatenates_list_content():
    adapter = InspectInstanceLevelDataAdapter(
        'test_id', 'test_id', 'jsonl', 'sha256', '/tmp'
    )

    msg_str = ChatMessageUser(content='plain string content')
    assert adapter._serialize_input([msg_str]) == 'plain string content'

    block1 = ContentText(text='Context: some context.')
    block2 = ContentText(text='Question: what is X?')
    msg_list = ChatMessageUser(content=[block1, block2])
    assert (
        adapter._serialize_input([msg_list])
        == 'Context: some context. Question: what is X?'
    )


def _convert_single_synthetic_sample(
    sample: SimpleNamespace,
    reductions: list[SimpleNamespace] | None = None,
) -> InstanceLevelEvaluationLog:
    with tempfile.TemporaryDirectory() as tmpdir:
        adapter = InspectInstanceLevelDataAdapter(
            'synthetic_test', 'synthetic_test', 'jsonl', 'sha256', tmpdir
        )
        path, rows_count = adapter.convert_instance_level_logs(
            'synthetic_eval',
            'synthetic/model',
            [sample],
            reductions=reductions,
        )
        assert rows_count == 1
        rows = Path(path).read_text(encoding='utf-8').splitlines()
        assert len(rows) == 1
        return InstanceLevelEvaluationLog.model_validate(json.loads(rows[0]))


def _make_synthetic_sample(
    *,
    sample_id: str,
    target: str,
    response_content: str,
    score_value: str | float | int | bool | None = None,
    score_answer: str | None = None,
    score_explanation: str | None = None,
    scorer_name: str = 'choice',
) -> SimpleNamespace:
    sample_scores = None
    if score_value is not None:
        sample_scores = {
            scorer_name: SimpleNamespace(
                value=score_value,
                answer=score_answer,
                explanation=score_explanation,
            )
        }

    return SimpleNamespace(
        id=sample_id,
        epoch=1,
        input='Synthetic prompt',
        target=target,
        choices=None,
        messages=[],
        output=SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content=response_content)
                )
            ],
            usage=None,
            stop_reason=None,
        ),
        scores=sample_scores,
        total_time=None,
        working_time=None,
        error=None,
    )


def test_reductions_override_answer_match_heuristic_for_score():
    sample = _make_synthetic_sample(
        sample_id='sample_1',
        target='target_answer',
        response_content='generated_response',
        score_value='C',
        score_answer='target_answer',
        scorer_name='bfcl_scorer',
    )
    reductions = [
        SimpleNamespace(
            scorer='bfcl_scorer',
            samples=[
                SimpleNamespace(
                    sample_id='sample_1',
                    value=0,
                    answer='target_answer',
                    explanation='',
                )
            ],
        )
    ]

    instance_log = _convert_single_synthetic_sample(
        sample, reductions=reductions
    )

    assert instance_log.evaluation.score == 0.0
    assert instance_log.evaluation.is_correct is False


def test_score_value_ci_fallback_without_reductions():
    sample = _make_synthetic_sample(
        sample_id='sample_2',
        target='target_answer',
        response_content='non_matching_answer',
        score_value='C',
        scorer_name='choice',
    )

    instance_log = _convert_single_synthetic_sample(sample, reductions=None)

    assert instance_log.evaluation.score == 1.0
    assert instance_log.evaluation.is_correct is True


def test_non_binary_numeric_score_marks_correct_even_without_ref_match():
    sample = _make_synthetic_sample(
        sample_id='sample_2b',
        target='target_answer',
        response_content='non_matching_answer',
        score_value=0.6,
        scorer_name='choice',
    )

    instance_log = _convert_single_synthetic_sample(sample, reductions=None)

    assert instance_log.evaluation.score == 0.6
    assert instance_log.evaluation.is_correct is True


def test_unparseable_score_value_falls_back_to_response_reference_match():
    sample = _make_synthetic_sample(
        sample_id='sample_3',
        target='target_answer',
        response_content='target_answer',
        score_value='unknown',
        scorer_name='choice',
    )

    instance_log = _convert_single_synthetic_sample(sample, reductions=None)

    assert instance_log.evaluation.score == 1.0
    assert instance_log.evaluation.is_correct is True


def test_unparseable_score_value_falls_back_to_reference_mismatch():
    sample = _make_synthetic_sample(
        sample_id='sample_3b',
        target='target_answer',
        response_content='non_matching_answer',
        score_value='unknown',
        scorer_name='choice',
    )

    instance_log = _convert_single_synthetic_sample(sample, reductions=None)

    assert instance_log.evaluation.score == 0.0
    assert instance_log.evaluation.is_correct is False
