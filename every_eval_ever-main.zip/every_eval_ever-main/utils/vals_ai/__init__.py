"""Vals.ai leaderboard adapter."""
