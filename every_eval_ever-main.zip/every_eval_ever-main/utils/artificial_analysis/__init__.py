"""Artificial Analysis adapter package."""
