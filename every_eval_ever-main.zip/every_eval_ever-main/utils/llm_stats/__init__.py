"""LLM Stats adapter package."""
