"""OpenEval adapter utilities."""
