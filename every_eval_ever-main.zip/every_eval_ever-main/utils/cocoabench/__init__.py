"""CocoaBench helpers and adapters."""
