from typing import Any, List

try:
    from helm.benchmark.adaptation.scenario_state import RequestState
except (
    Exception
):  # pragma: no cover - exercised only when optional deps missing
    RequestState = Any  # type: ignore[assignment]


def extract_reasoning(request_state: RequestState) -> str | None:
    if request_state.result and request_state.result.completions:
        return getattr(
            getattr(request_state.result.completions[0], 'thinking', None),
            'text',
            None,
        )

    return None


def extract_all_reasonings(request_state: RequestState) -> List[str] | None:
    if not (request_state.result and request_state.result.completions):
        return None

    traces = [
        getattr(getattr(c, 'thinking', None), 'text', None)
        for c in request_state.result.completions
        if getattr(c, 'thinking', None) is not None
    ]
    # thinking.text can itself be None; drop those to satisfy list[str] schema
    traces = [t for t in traces if t is not None]
    return traces if traces else None
