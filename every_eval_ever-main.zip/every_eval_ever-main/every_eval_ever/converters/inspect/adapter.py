import json
import logging
import os
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Tuple, Union
from urllib.parse import urlparse

_INSPECT_IMPORT_ERROR: Exception | None = None
try:
    from inspect_ai.log import (
        EvalDataset,
        EvalLog,
        EvalMetric,
        EvalResults,
        EvalSample,
        EvalSampleSummary,
        EvalScore,
        EvalSpec,
        EvalStats,
        list_eval_logs,
        read_eval_log,
        read_eval_log_sample,
        read_eval_log_sample_summaries,
    )
    from inspect_ai.log import EvalPlan as InspectEvalPlan
except (
    Exception
) as ex:  # pragma: no cover - exercised only when optional deps missing
    _INSPECT_IMPORT_ERROR = ex
    EvalDataset = EvalLog = EvalMetric = EvalResults = EvalSample = (
        EvalSampleSummary
    ) = EvalScore = EvalStats = EvalSpec = Any  # type: ignore[assignment]
    InspectEvalPlan = Any  # type: ignore[assignment]


def _require_inspect_dependencies() -> None:
    if _INSPECT_IMPORT_ERROR is not None:
        raise ImportError(
            'Inspect converter dependencies are missing. '
            "Install with: pip install 'every_eval_ever[inspect]'"
        ) from _INSPECT_IMPORT_ERROR


from every_eval_ever.converters import SCHEMA_VERSION
from every_eval_ever.converters.common.adapter import (
    AdapterMetadata,
    BaseEvaluationAdapter,
    SupportedLibrary,
)
from every_eval_ever.converters.common.error import AdapterError
from every_eval_ever.converters.common.utils import (
    convert_timestamp_to_unix_format,
    get_current_unix_timestamp,
    sha256_file,
)
from every_eval_ever.converters.inspect.instance_level_adapter import (
    InspectInstanceLevelDataAdapter,
)
from every_eval_ever.converters.inspect.utils import (
    apply_supplemental_eval_details,
    extract_model_info_from_model_path,
    parse_supplemental_eval_details,
)
from every_eval_ever.eval_types import (
    AgenticEvalConfig,
    AvailableTool,
    DetailedEvaluationResults,
    EvalLibrary,
    EvalLimits,
    EvalPlan,
    EvaluationLog,
    EvaluationResult,
    EvaluatorRelationship,
    Format,
    GenerationArgs,
    GenerationConfig,
    HashAlgorithm,
    JudgeConfig,
    LlmScoring,
    MetricConfig,
    ModelInfo,
    Sandbox,
    ScoreDetails,
    ScoreType,
    SourceDataHf,
    SourceDataPrivate,
    SourceMetadata,
    SourceType,
    StandardError,
    Uncertainty,
)

logger = logging.getLogger(__name__)


class InspectAIAdapter(BaseEvaluationAdapter):
    """
    Adapter for transforming evaluation outputs from the Inspect AI library into the unified schema format.
    """

    def __init__(self, strict_validation: bool = True):
        _require_inspect_dependencies()
        super().__init__(strict_validation)

    @property
    def metadata(self) -> AdapterMetadata:
        return AdapterMetadata(
            name='InspectAdapter',
            version='0.0.1',
            description='Adapter for transforming Inspect evaluation outputs to unified schema format',
        )

    @property
    def supported_library(self) -> SupportedLibrary:
        return SupportedLibrary.INSPECT_AI

    def _extract_uncertainty(
        self, stderr_value: float, stddev_value: float, num_samples: int
    ) -> Uncertainty:
        return Uncertainty(
            standard_error=StandardError(value=stderr_value)
            if stderr_value
            else None,
            standard_deviation=stddev_value,
            num_samples=num_samples,
        )

    def _build_evaluation_result(
        self,
        evaluation_task_name: str,
        scorer_name: str,
        metric_info: EvalMetric,
        llm_grader: LlmScoring,
        source_data: SourceDataHf,
        evaluation_timestamp: str,
        generation_config: GenerationConfig,
        stderr_value: float | None = None,
        stddev_value: float | None = None,
        num_samples: int = 0,
    ) -> EvaluationResult:
        return EvaluationResult(
            evaluation_name=f'{metric_info.name} on {evaluation_task_name} for scorer {scorer_name}',
            source_data=source_data,
            evaluation_timestamp=evaluation_timestamp,
            metric_config=MetricConfig(
                evaluation_description=metric_info.name,
                lower_is_better=False,  # no metadata available
                score_type=ScoreType.continuous,
                min_score=0,
                max_score=1,
                llm_scoring=llm_grader,
            ),
            score_details=ScoreDetails(
                score=metric_info.value,
                uncertainty=self._extract_uncertainty(
                    stderr_value, stddev_value, num_samples
                ),
            ),
            generation_config=generation_config,
        )

    def _extract_evaluation_results(
        self,
        evaluation_task_name: str,
        scores: List[EvalScore],
        source_data: SourceDataHf,
        generation_config: GenerationConfig,
        num_samples: int,
        timestamp: str,
    ) -> List[EvaluationResult]:
        results: List[EvaluationResult] = []

        for scorer in scores:
            llm_grader = None
            if scorer.params and scorer.params.get('grader_model'):
                llm_grader = LlmScoring(
                    judges=[
                        JudgeConfig(
                            model_info=extract_model_info_from_model_path(
                                self._safe_get(
                                    scorer.params.get('grader_model'), 'model'
                                )
                            )
                        )
                    ],
                    input_prompt=self._safe_get(
                        scorer.params, 'grader_template'
                    ),
                )

            stderr_value = next(
                (
                    m.value
                    for m in scorer.metrics.values()
                    if m.name == 'stderr'
                ),
                None,
            )

            stddev_value = next(
                (
                    m.value
                    for m in scorer.metrics.values()
                    if m.name in {'std', 'stddev'}
                ),
                None,
            )

            for _, metric_info in scorer.metrics.items():
                if metric_info.name == 'stderr':
                    continue

                scorer_name = scorer.name or scorer.scorer

                results.append(
                    self._build_evaluation_result(
                        evaluation_task_name=evaluation_task_name,
                        scorer_name=scorer_name,
                        metric_info=metric_info,
                        llm_grader=llm_grader,
                        source_data=source_data,
                        evaluation_timestamp=timestamp,
                        generation_config=generation_config,
                        stderr_value=stderr_value,
                        stddev_value=stddev_value,
                        num_samples=num_samples,
                    )
                )

        return results

    # A HuggingFace repo identifier: exactly `namespace/name` with no
    # extra path segments, schemes, or path-unsafe prefixes. We use an
    # allowlist regex because the set of "real HF repos" is much easier
    # to characterize precisely than the set of "local paths".
    _HF_REPO_RE = re.compile(r'^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$')

    @classmethod
    def _looks_like_local_path(cls, location: str | None) -> bool:
        """Heuristic: is `dataset.location` a local filesystem path rather
        than a HuggingFace repo identifier?

        A valid HF repo is exactly `namespace/name`. Anything else —
        absolute/relative paths (`/`, `./`, `../`, `~`), Windows drive
        letters, URL schemes (`file://`, `http://`), three-or-more
        segment paths (e.g. `inspect_evals/gaia_dataset/GAIA` from older
        Inspect versions), or plain single words — we treat as local.
        """
        if not location:
            return False
        return not cls._HF_REPO_RE.match(location)

    def _extract_source_data(
        self, dataset: EvalDataset, task_name: str
    ) -> SourceDataHf | SourceDataPrivate:
        sample_ids = (
            [str(sid) for sid in dataset.sample_ids]
            if dataset.sample_ids is not None
            else None
        )

        if self._looks_like_local_path(dataset.location):
            # dataset.location is not a valid HF repo identifier: it may
            # be an absolute filesystem path (e.g. a cached HF dataset
            # or a benchmark's bundled challenges directory) or some
            # other non-HF reference. We can't claim this is an HF
            # dataset, and `dataset.name` is often an internal filename
            # that doesn't identify the benchmark (e.g. 'challenges' for
            # cyberseceval_2 vulnerability_exploit, 'ic_ctf' for
            # gdm_intercode_ctf). Use the canonical inspect_evals task
            # name as `dataset_name`, and preserve the harness-provided
            # `dataset.name` and `dataset.location` in
            # `additional_details` for anyone who needs the raw values.
            dataset_name = (
                task_name.split('/')[-1]
                if task_name
                else (dataset.name.split('/')[-1] if dataset.name else '')
            )
            additional_details: dict[str, str] = {
                'shuffled': str(dataset.shuffled),
            }
            if dataset.location:
                additional_details['inspect_dataset_location'] = str(
                    dataset.location
                )
            if dataset.name:
                additional_details['inspect_dataset_name'] = dataset.name
            if dataset.samples is not None:
                additional_details['samples_number'] = str(dataset.samples)
            if sample_ids is not None:
                additional_details['sample_ids'] = ','.join(sample_ids)
            return SourceDataPrivate(
                source_type='other',
                dataset_name=dataset_name,
                additional_details=additional_details,
            )

        # Real HF dataset: trust `dataset.name` as the benchmark
        # identifier. When the harness sets it to the full repo id
        # (e.g. `bigbio/pubmed_qa`), take the final path segment.
        dataset_name = (
            dataset.name.split('/')[-1]
            if dataset.name
            else task_name.split('/')[-1]
        )
        return SourceDataHf(  # TODO add hf_split
            source_type='hf_dataset',
            dataset_name=dataset_name,
            hf_repo=dataset.location,
            samples_number=dataset.samples,
            sample_ids=sample_ids,
            additional_details={'shuffled': str(dataset.shuffled)},
        )

    def _safe_get(self, obj: Any, field: str):
        cur = obj

        if cur is None:
            return None

        if isinstance(cur, dict):
            cur = cur.get(field)
        else:
            cur = getattr(cur, field, None)

        return cur

    def _extract_available_tools(
        self, eval_plan: InspectEvalPlan
    ) -> List[AvailableTool]:
        """Extracts and flattens tools from the evaluation plan steps."""

        tools_in_plan_steps = [
            step.params.get('tools', [])
            for step in eval_plan.steps
            if step.solver == 'use_tools'
        ]

        return [
            AvailableTool(
                name=self._safe_get(tool, 'name'),
                description=self._safe_get(tool, 'description'),
                parameters=(
                    {str(k): json.dumps(v) for k, v in raw_params.items()}
                    if (raw_params := self._safe_get(tool, 'params'))
                    and isinstance(raw_params, dict)
                    else None
                ),
            )
            for tool_list in tools_in_plan_steps
            if isinstance(tool_list, list) and tool_list
            for tool in tool_list[0]
        ]

    def _extract_prompt_template(self, plan: InspectEvalPlan) -> str | None:
        for step in plan.steps:
            if step.solver == 'prompt_template':
                return self._safe_get(step.params, 'template')

        return None

    def _extract_generation_config(
        self, spec: EvalSpec, inspect_plan: InspectEvalPlan
    ) -> GenerationConfig:
        eval_config = spec.model_generate_config
        eval_generation_config = {
            gen_config: json.dumps(value)
            for gen_config, value in vars(eval_config).items()
            if value is not None
        }
        eval_sandbox = spec.task_args.get('sandbox', None)
        if eval_sandbox and not isinstance(eval_sandbox, list):
            eval_sandbox = [eval_sandbox]
        sandbox_type, sandbox_config = ((eval_sandbox or []) + [None, None])[:2]

        eval_plan = EvalPlan(
            name=inspect_plan.name,
            steps=[
                json.dumps(
                    step.model_dump()
                    if hasattr(step, 'model_dump')
                    else vars(step)
                )
                for step in inspect_plan.steps
            ],
            config={
                str(k): json.dumps(v)
                for k, v in inspect_plan.config.model_dump().items()
                if v is not None
            },
        )

        eval_limits = EvalLimits(
            time_limit=spec.config.time_limit,
            message_limit=spec.config.message_limit,
            token_limit=spec.config.token_limit,
        )

        max_attempts = (
            spec.task_args.get('max_attempts') or eval_config.max_retries
        )  # TODO not sure if max_attempts == max_retries in this case

        reasoning = (
            True
            if eval_config.reasoning_effort
            and eval_config.reasoning_effort.lower() != 'none'
            else False
        )

        available_tools: List[AvailableTool] = self._extract_available_tools(
            inspect_plan
        )

        generation_args = GenerationArgs(
            temperature=eval_config.temperature,
            top_p=eval_config.top_p,
            top_k=eval_config.top_k,
            max_tokens=eval_config.max_tokens,
            reasoning=reasoning,
            prompt_template=self._extract_prompt_template(inspect_plan),
            agentic_eval_config=AgenticEvalConfig(
                available_tools=available_tools
            ),
            eval_plan=eval_plan,
            eval_limits=eval_limits,
            sandbox=Sandbox(type=sandbox_type, config=sandbox_config),
            max_attempts=max_attempts,
        )

        additional_details = eval_generation_config

        return GenerationConfig(
            generation_args=generation_args,
            additional_details=additional_details or None,
        )

    def _extract_library_version(self, packages: Dict[str, str]) -> str:
        parts = [
            f'{name}:{version}' for name, version in packages.items() if version
        ]
        return ','.join(parts)

    def transform_from_directory(
        self, dir_path: Union[str, Path], metadata_args: Dict[str, Any] = None
    ) -> List[EvaluationLog]:
        metadata_args = metadata_args or {}

        if isinstance(dir_path, str):
            dir_path = Path(dir_path)

        if not dir_path.exists():
            raise FileNotFoundError(
                f'Directory path {dir_path} does not exist!'
            )

        log_paths: List[Path] = list_eval_logs(dir_path.absolute().as_posix())
        file_uuids = metadata_args.get('file_uuids')
        try:
            transformed_logs: List[EvaluationLog] = []
            for idx, log_path in enumerate(log_paths):
                # In directory mode, each converted log must get its own UUID.
                per_log_metadata_args = dict(metadata_args)
                file_uuid = None
                if isinstance(file_uuids, list) and idx < len(file_uuids):
                    file_uuid = file_uuids[idx]
                per_log_metadata_args['file_uuid'] = file_uuid or str(
                    uuid.uuid4()
                )
                transformed_logs.append(
                    self.transform_from_file(
                        urlparse(log_path.name).path,
                        per_log_metadata_args,
                    )
                )
            return transformed_logs
        except Exception as e:
            raise AdapterError(
                f'Failed to load file from directory {dir_path}: {str(e)} for InspectAIAdapter'
            )

    def transform_from_file(
        self,
        file_path: Union[str, Path],
        metadata_args: Dict[str, Any] = None,
        header_only: bool = False,
    ) -> Union[EvaluationLog, List[EvaluationLog]]:
        metadata_args = metadata_args or {}

        if not os.path.exists(file_path):
            raise FileNotFoundError(f'File path {file_path} does not exists!')

        try:
            file_path = (
                Path(file_path) if isinstance(file_path, str) else file_path
            )
            eval_data: Tuple[
                EvalLog, List[EvalSampleSummary], EvalSample | None
            ] = self._load_file(file_path, header_only=header_only)
            return self.transform(eval_data, metadata_args)
        except AdapterError as e:
            raise e
        except Exception as e:
            raise AdapterError(
                f'Failed to load file {file_path}: {str(e)} for InspectAIAdapter'
            )

    def _transform_single(
        self,
        raw_data: Tuple[EvalLog, List[EvalSampleSummary], EvalSample | None],
        metadata_args: Dict[str, Any],
    ) -> EvaluationLog:
        metadata_args = metadata_args or {}

        raw_eval_log, sample_summaries, single_sample = raw_data
        eval_spec: EvalSpec = raw_eval_log.eval
        eval_stats: EvalStats = raw_eval_log.stats

        evaluation_timestamp = eval_stats.started_at or eval_spec.created
        evaluation_unix_timestamp = convert_timestamp_to_unix_format(
            evaluation_timestamp
        )
        retrieved_unix_timestamp = get_current_unix_timestamp()

        if not evaluation_unix_timestamp:
            evaluation_unix_timestamp = retrieved_unix_timestamp

        library_version = self._extract_library_version(eval_spec.packages)
        eval_library = EvalLibrary(
            name=metadata_args.get('eval_library_name', 'inspect_ai'),
            version=library_version
            or metadata_args.get('eval_library_version', 'unknown'),
        )

        evaluator_relationship = metadata_args.get(
            'evaluator_relationship', EvaluatorRelationship.third_party
        )
        if isinstance(evaluator_relationship, str):
            evaluator_relationship = EvaluatorRelationship(
                evaluator_relationship
            )

        source_metadata = SourceMetadata(
            source_name='inspect_ai',
            source_type=SourceType.evaluation_run,
            source_organization_name=metadata_args.get(
                'source_organization_name', 'unknown'
            ),
            source_organization_url=metadata_args.get(
                'source_organization_url'
            ),
            source_organization_logo_url=metadata_args.get(
                'source_organization_logo_url'
            ),
            evaluator_relationship=evaluator_relationship,
        )

        source_data = self._extract_source_data(
            eval_spec.dataset, eval_spec.task
        )

        model_path = eval_spec.model

        num_samples = len(raw_eval_log.samples) if raw_eval_log.samples else 0
        single_sample = (
            raw_eval_log.samples[0] if raw_eval_log.samples else single_sample
        )

        if single_sample:
            detailed_model_name = single_sample.output.model

            if '/' in model_path:
                prefix, rest = model_path.split('/', 1)

                if rest != detailed_model_name:
                    model_path = f'{prefix}/{detailed_model_name}'
                else:
                    model_path = f'{prefix}/{rest}'
            else:
                model_path = detailed_model_name

        model_info: ModelInfo = extract_model_info_from_model_path(model_path)

        generation_config = self._extract_generation_config(
            eval_spec, raw_eval_log.plan
        )

        results: EvalResults | None = raw_eval_log.results

        evaluation_task_name = eval_spec.task_display_name or eval_spec.task

        evaluation_results = (
            self._extract_evaluation_results(
                evaluation_task_name,
                results.scores if results else [],
                source_data,
                generation_config,
                num_samples,
                evaluation_unix_timestamp,
            )
            if results and results.scores
            else []
        )

        supplemental_eval_details = parse_supplemental_eval_details(
            metadata_args.get('supplemental_eval_details')
        )

        apply_supplemental_eval_details(
            model_info=model_info,
            evaluation_results=evaluation_results,
            supplemental_eval_details=supplemental_eval_details,
        )

        evaluation_id = f'{source_data.dataset_name}/{model_path.replace("/", "_")}/{evaluation_unix_timestamp}'

        parent_eval_output_dir = metadata_args.get(
            'parent_eval_output_dir', 'data'
        )
        if raw_eval_log.samples and parent_eval_output_dir:
            file_uuid = metadata_args.get('file_uuid')
            if not file_uuid:
                file_uuid = str(uuid.uuid4())
                metadata_args['file_uuid'] = file_uuid
                logging.warning(
                    f"Missing metadata_args['file_uuid']; generated one for instance-level log: {file_uuid}. "
                    'Save unified aggregate log with the same uuid.'
                )

            if '/' in model_info.id:
                model_dev, model_name = model_info.id.split('/', 1)
            else:
                model_dev, model_name = 'unknown', model_info.id
            evaluation_dir = f'{parent_eval_output_dir}/{source_data.dataset_name}/{model_dev}/{model_name}'
            # The aggregate `evaluation_id` is the foreign key consumers
            # use to join instance-level records back to the aggregate,
            # so pass it through verbatim. The file basename is a
            # separate, filesystem-safe identifier since the aggregate
            # id contains slashes and other path-unsafe characters.
            file_basename = f'{file_uuid}_samples'

            instance_level_log_path, instance_level_rows_number = (
                InspectInstanceLevelDataAdapter(
                    evaluation_id=evaluation_id,
                    file_basename=file_basename,
                    format=Format.jsonl.value,
                    hash_algorithm=HashAlgorithm.sha256.value,
                    evaluation_dir=evaluation_dir,
                ).convert_instance_level_logs(
                    evaluation_task_name,
                    model_info.id,
                    raw_eval_log.samples,
                    getattr(raw_eval_log, 'reductions', None),
                )
            )

            detailed_evaluation_results = DetailedEvaluationResults(
                format=Format.jsonl,
                file_path=instance_level_log_path,
                hash_algorithm=HashAlgorithm.sha256.value,
                checksum=sha256_file(instance_level_log_path),
                total_rows=instance_level_rows_number,
            )
        else:
            detailed_evaluation_results = None

        return EvaluationLog(
            schema_version=SCHEMA_VERSION,
            evaluation_id=evaluation_id,
            evaluation_timestamp=evaluation_unix_timestamp,
            retrieved_timestamp=retrieved_unix_timestamp,
            source_metadata=source_metadata,
            eval_library=eval_library,
            model_info=model_info,
            evaluation_results=evaluation_results,
            detailed_evaluation_results=detailed_evaluation_results,
        )

    def _load_file(
        self, file_path, header_only=False
    ) -> Tuple[EvalLog, List[EvalSampleSummary], EvalSample | None]:
        log = read_eval_log(file_path, header_only=header_only)
        if header_only:
            summaries = read_eval_log_sample_summaries(file_path)
            first_sample = (
                read_eval_log_sample(
                    file_path, summaries[0].id, summaries[0].epoch
                )
                if summaries
                else None
            )
        else:
            summaries = []
            first_sample = None

        return log, summaries, first_sample
